package com.rays.get;

public interface UserDAOInt {
public UserDTO findByPk(Long pk);
}
