package com.rays.get;

public interface UserServiceInt {
	public UserDTO findById(Long id);

}
