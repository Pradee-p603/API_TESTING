package com.rays.authenticate;

public interface UserServiceInt {
	public UserDTO authenticate(String loginId , String password);

}
