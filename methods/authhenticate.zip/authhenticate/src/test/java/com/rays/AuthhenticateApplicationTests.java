package com.rays;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthhenticateApplicationTests {

	@Test
	void contextLoads() {
	}

}
