package com.rays.dao;

import com.rays.common.BaseDAOInt;
import com.rays.dto.UserDTO;

public interface UserDAOInt extends BaseDAOInt<UserDTO>{

}
