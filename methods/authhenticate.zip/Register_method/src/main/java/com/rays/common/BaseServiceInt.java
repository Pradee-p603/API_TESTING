package com.rays.common;

import java.util.List;

import com.rays.dto.UserDTO;

public interface BaseServiceInt<T extends BaseDTO> {


}
