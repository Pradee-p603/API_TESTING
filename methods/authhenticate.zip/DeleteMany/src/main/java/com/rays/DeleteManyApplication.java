package com.rays;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeleteManyApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeleteManyApplication.class, args);
	}

}
