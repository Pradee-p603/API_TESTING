package com.rays.save;

public interface UserDAOInt {

	public void update(UserDTO dto);
	
	public long add(UserDTO dto);
}
