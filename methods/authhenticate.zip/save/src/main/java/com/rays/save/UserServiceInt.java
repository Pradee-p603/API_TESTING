package com.rays.save;

public interface UserServiceInt {
	
	public void update(UserDTO dto);
	
	public long add(UserDTO dto);

}
